$('#botao-frase').click(fraseAleatoria);
$('#botao-frase-id').click(buscaFrase);

function fraseAleatoria() {
    $('#spinner').show();

    $.get("http://localhost:3000/frases", trocaFraseAleatoria)
    .fail(function(){
        $("#erro").toggle();
        setTimeout(function(){
            $("#erro").toggle();
        },1500);
    })
    .always(function() {
        $('#spinner').hide();
    });
}

function trocaFraseAleatoria(data){
    var numAleatorio = Math.floor(Math.random() * data.length);
    var frase = $('.frase').text(data[numAleatorio].texto);
    atualizaTamanhoFrase();
    atualizaTempoInicial(data[numAleatorio].tempo);
}

function buscaFrase(){
    $('#spinner').show();

    var dados = {
        id: $('#frase-id').val()
    }
    $.get('http://localhost:3000/frases', dados, trocaFrase)
    .fail(function(){
        $("#erro").toggle();
        setTimeout(function(){
            $("#erro").toggle();
        },1500);
    })
    .always(function() {
        $('#spinner').hide();
    });
}

function trocaFrase(data){
    $('.frase').text(data.texto);
    atualizaTamanhoFrase();
    atualizaTempoInicial(data.tempo);
}